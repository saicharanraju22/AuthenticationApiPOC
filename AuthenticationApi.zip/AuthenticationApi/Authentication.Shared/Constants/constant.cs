﻿using System.Security.Claims;

namespace Authentication.Shared;
    public static class constant
    {
        public const string Claimtype= "http://schemas.microsoft.com/ws/2008/06/identity/claims/role";


    }

    public static class Employeeroles
    {
        public const string EMPLOYEE = "Employee";
        public const string MANAGER = "Manager";
        public const string ADMIN = "Admin";
     }


     public static class AUTHENTICATION
     {
      public const string VALIDISSUER = "https://localhost:7080";
      public const string VALIDAUDIENCE = "https://localhost:7080";
      public const string SECRETKEY = "secretkey@secretkey@secretkey";
}




