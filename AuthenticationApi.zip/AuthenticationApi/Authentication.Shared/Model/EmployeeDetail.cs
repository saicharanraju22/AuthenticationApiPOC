﻿using System;
using System.Collections.Generic;

namespace AuthenticationApi.Web.Model;

public partial class EmployeeDetail
{
    public int Id { get; set; }

    public string? Name { get; set; }

    public string? HireDate { get; set; }

    public string? Domain { get; set; }

    public string? DepId { get; set; }

    public string? Role { get; set; }

    public virtual Department? Dep { get; set; }

    public virtual ICollection<UserDetail> UserDetails { get; } = new List<UserDetail>();
}
