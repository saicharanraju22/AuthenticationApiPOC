﻿using System;
using System.Collections.Generic;

namespace AuthenticationApi.Web.Model;

public partial class UserDetail
{
    public string Username { get; set; } = null!;

    public string? Password { get; set; }

    public int? EmpId { get; set; }

    public virtual EmployeeDetail? Emp { get; set; }
}
