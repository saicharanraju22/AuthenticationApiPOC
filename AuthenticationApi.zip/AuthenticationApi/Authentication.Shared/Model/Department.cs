﻿using System;
using System.Collections.Generic;

namespace AuthenticationApi.Web.Model;

public partial class Department
{
    public string DepId { get; set; } = null!;

    public string? DepName { get; set; }

    public string? DepLocation { get; set; }

    public virtual ICollection<EmployeeDetail> EmployeeDetails { get; } = new List<EmployeeDetail>();
}
