﻿using Authentication.DataAccess.Repositories;
using AuthenticationApi.Web.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Authentication.Business
{
    public interface IEmployeeDetailsService
    {
        public string GetToken(string username, string password);

        public IQueryable<UserDetail> GetEmployees();

        public IQueryable<Department> GetDepartmentDetails();

    }
}
