﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Authentication.DataAccess.Repositories;
using AuthenticationApi.Web.Model;

namespace Authentication.Business
{
    public class EmployeeDetailsService : IEmployeeDetailsService
    {

        private readonly IEmployeeDetailsRepository _employeeDetailsRepository;

        public EmployeeDetailsService(IEmployeeDetailsRepository employeeDetailsRepository)
        {
            _employeeDetailsRepository = employeeDetailsRepository ?? throw new ArgumentNullException(nameof(_employeeDetailsRepository));
        }

        /// <summary>
        /// Gets the role for token
        /// </summary>
        /// <param name="username"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public string GetToken(string username, string password)
        {
            var employeeRoleDetails = _employeeDetailsRepository.GetEmployeeRoleDetails(username, password);

            if (employeeRoleDetails == null)
            {
                return null;
            }
            return employeeRoleDetails.Role;

        }
        /// <summary>
        /// GetEmployeeDetails
        /// </summary>
        /// <returns></returns>

        public IQueryable<UserDetail> GetEmployees()
        {
            var details = _employeeDetailsRepository.GetEmployeeDetails();
            return details;
        }


        public IQueryable<Department> GetDepartmentDetails()
        {
            var details = _employeeDetailsRepository.GetDepartmentDetails();
            return details;
        }



    }
}
