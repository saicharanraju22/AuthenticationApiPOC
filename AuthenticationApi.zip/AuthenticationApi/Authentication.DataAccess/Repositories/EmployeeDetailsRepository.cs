﻿using AuthenticationApi.Web.Model;

namespace Authentication.DataAccess.Repositories
{


    public class EmployeeDetailsRepository: IEmployeeDetailsRepository
    {

        private readonly UserAuthenticationContext _context;


        public EmployeeDetailsRepository(UserAuthenticationContext context)
        {
            _context = context;
        }

        public EmployeeDetail GetEmployeeRoleDetails(string username, string password)
        {
            var employee = _context.UserDetails.FirstOrDefault(e => e.Username == username && e.Password == password);

            if (employee == null)
            {
                return null;
            }

            var employeeRoleDetails = _context.EmployeeDetails.FirstOrDefault(e => e.Id == employee.EmpId);
            return employeeRoleDetails;

        }

        public IQueryable<UserDetail> GetEmployeeDetails()
        {
            var employee = _context.UserDetails;
            return employee;

        }


        public IQueryable<Department> GetDepartmentDetails()
        {
            var employee = _context.Departments;
            return employee;

        }








    }
}
