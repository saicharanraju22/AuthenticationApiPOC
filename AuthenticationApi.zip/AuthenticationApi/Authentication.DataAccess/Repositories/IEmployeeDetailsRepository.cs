﻿
using AuthenticationApi.Web.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Authentication.DataAccess.Repositories
{
    public interface IEmployeeDetailsRepository
    {
        public EmployeeDetail GetEmployeeRoleDetails(string username, string password);

        public IQueryable<UserDetail> GetEmployeeDetails();


        public IQueryable<Department> GetDepartmentDetails();
    }
}
