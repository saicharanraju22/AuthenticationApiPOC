﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace AuthenticationApi.Web.Model;

public partial class UserAuthenticationContext : DbContext
{
    public UserAuthenticationContext()
    {
    }

    public UserAuthenticationContext(DbContextOptions<UserAuthenticationContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Department> Departments { get; set; }

    public virtual DbSet<EmployeeDetail> EmployeeDetails { get; set; }

    public virtual DbSet<UserDetail> UserDetails { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=GGKU5DELL1492\\SQLEXPRESS;Database=UserAuthentication;Trusted_Connection=True;TrustServerCertificate=True");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Department>(entity =>
        {
            entity.HasKey(e => e.DepId);

            entity.ToTable("Department");

            entity.Property(e => e.DepId)
                .HasMaxLength(10)
                .IsFixedLength()
                .HasColumnName("Dep_Id");
            entity.Property(e => e.DepLocation)
                .HasMaxLength(10)
                .IsFixedLength()
                .HasColumnName("Dep_Location");
            entity.Property(e => e.DepName)
                .HasMaxLength(10)
                .IsFixedLength()
                .HasColumnName("Dep_Name");
        });

        modelBuilder.Entity<EmployeeDetail>(entity =>
        {
            entity.Property(e => e.Id).ValueGeneratedNever();
            entity.Property(e => e.DepId)
                .HasMaxLength(10)
                .IsFixedLength()
                .HasColumnName("Dep_id");
            entity.Property(e => e.Domain)
                .HasMaxLength(10)
                .IsFixedLength();
            entity.Property(e => e.HireDate)
                .HasMaxLength(10)
                .IsFixedLength()
                .HasColumnName("Hire_Date");
            entity.Property(e => e.Name)
                .HasMaxLength(10)
                .IsFixedLength();
            entity.Property(e => e.Role)
                .HasMaxLength(10)
                .IsFixedLength();

            entity.HasOne(d => d.Dep).WithMany(p => p.EmployeeDetails)
                .HasForeignKey(d => d.DepId)
                .HasConstraintName("FK_EmployeeDetails_Department");
        });

        modelBuilder.Entity<UserDetail>(entity =>
        {
            entity.HasKey(e => e.Username);

            entity.Property(e => e.Username)
                .HasMaxLength(10)
                .IsFixedLength();
            entity.Property(e => e.EmpId).HasColumnName("emp_id");
            entity.Property(e => e.Password)
                .HasMaxLength(10)
                .IsFixedLength();

            entity.HasOne(d => d.Emp).WithMany(p => p.UserDetails)
                .HasForeignKey(d => d.EmpId)
                .HasConstraintName("FK_UserDetails_EmployeeDetails");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
