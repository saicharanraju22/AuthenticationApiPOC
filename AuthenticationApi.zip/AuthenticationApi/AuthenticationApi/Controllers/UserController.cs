﻿
using Authentication.Shared;
using AuthenticationApi.Web.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Linq;
using Authentication.Business;

namespace AuthenticationApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class UserController : ControllerBase
    {

        private readonly IEmployeeDetailsService _employeeDetailsService;
        public UserController(IEmployeeDetailsService employeeDetailsService)
        {
            _employeeDetailsService = employeeDetailsService;
        }
        /// <summary>
        /// Genetrate jWT Token
        /// </summary>
        /// <param name="username"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        [HttpPost("generate")]
        public IActionResult GenerateToken(string username, string password)
        {

            var roles = _employeeDetailsService.GetToken(username, password);
            if (roles == null)
            {
                return BadRequest();
            }
            var claims = new[]
            {
                  new Claim(ClaimTypes.Role, roles.Trim())
            };
            var key = new SymmetricSecurityKey(System.Text.Encoding.UTF8.GetBytes(AUTHENTICATION.SECRETKEY));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var token = new JwtSecurityToken(
                issuer: "https://localhost:7080",
                audience: "https://localhost:7080",
                claims: claims,
                expires: DateTime.UtcNow.AddMinutes(15),
                signingCredentials: creds
            );
            var Tokenresponse = new JwtSecurityTokenHandler().WriteToken(token);
            return Ok(Tokenresponse);
        }

        /// <summary>
        /// GetsEmployeeDetails
        /// </summary>
        /// <returns></returns>
        [Authorize(Policy = Employeeroles.MANAGER)]
        [HttpGet("employee")]
        public ActionResult GetEmployeedetails()
        {
            var details = _employeeDetailsService.GetEmployees();
            return Ok(details);
        }

        /// <summary>
        /// GetsUserClaims
        /// </summary>
        /// <returns></returns>

        [Authorize]
        [HttpGet("userroleclaim")]
        public ActionResult GetRoledetail()
        {
            //getting user claims
            var user = User;

            return Ok(user.FindFirstValue(ClaimTypes.Role));
        }
        /// <summary>
        /// Gets Department details
        /// </summary>
        /// <returns></returns>

        [Authorize(Policy = Employeeroles.ADMIN)]
        [HttpGet("department")]
        public ActionResult GetDepartment()
        {
            var details = _employeeDetailsService.GetDepartmentDetails();
            return Ok(details);
        }



    }
}
