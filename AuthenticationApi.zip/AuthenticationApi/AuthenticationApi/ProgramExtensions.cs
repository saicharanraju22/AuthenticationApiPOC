﻿using Authentication.Business;
using Authentication.DataAccess.Repositories;

namespace AuthenticationApi.Web
{
    public static class ProgramExtensions
    {

        public static void ResolveDependacies(this WebApplicationBuilder builder)
        {
            builder.Services.AddTransient<IEmployeeDetailsService, EmployeeDetailsService>();
            builder.Services.AddTransient<IEmployeeDetailsRepository, EmployeeDetailsRepository>();
        }




















    }
}
